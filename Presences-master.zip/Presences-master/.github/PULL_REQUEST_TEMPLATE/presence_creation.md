---
Name: Presence Creation
About: Pull request template for adding presences.
---

_In order to property create presences, please take a look at the [documentation](https://docs.premid.app/dev/presence). Take a look at the guidelines to see what is acceptable._

**Screenshots**
Please upload screenshots to github showing what the presence looks like in action. _Do not use third-party image hosting websites._

> After your pull request has been made, you should have a screenshot and the code.
